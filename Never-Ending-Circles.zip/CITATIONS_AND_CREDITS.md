# Project Name
Project name taken from the song "Never Ending Circles" by CHVRCHES

# Images
https://stock.adobe.com/images/vintage-classic-blue-texture-of-paper-background-with-copy-space-for-text-or-image/309246316?prev_url=detail

# Hit sound effect from 'Osu!'
https://osu.ppy.sh/home

# Music
Level 1 Music:
A Dance of Fire and Ice OST - https://www.youtube.com/watch?v=roKDAZ82i_0
Level 2 Music
A Dance of Fire and Ice OST - https://www.youtube.com/watch?v=aVLrALO2bmY
Level 3 Music
A Dance of Fire and Ice OST - https://www.youtube.com/watch?v=aTk7ekCkkVA&t=5s
Level 4 Music
A Dance of Fire and Ice OST - https://www.youtube.com/watch?v=pAt6NvO8QC0

# Fail Sound Effect
A Dance of Fire and Ice - https://store.steampowered.com/app/977950/A_Dance_of_Fire_and_Ice/

# Fonts
godoMaum - https://www.sandollcloud.com/font/16058.html?lang=en_US
Unmasked BB - https://www.fontspace.com/unmasked-bb-font-f10132

# Backgrounds
Main Menu - Main Menu - https://www.theartofkylelabriola.com/dance-of-fire-and-ice
Level 1 - https://wallpaperaccess.com/wide-hd
Level 2 - http://wallpaperswide.com/outrun-wallpapers.html
Level 3 - https://wallpapercave.com/w/wp4472144
Level 4 - https://wallpapersden.com/purple-hysteresis-abstract-wallpaper/3440x1440/